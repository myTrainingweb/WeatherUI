import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-weather></app-weather>'
})
export class AppComponent {}
